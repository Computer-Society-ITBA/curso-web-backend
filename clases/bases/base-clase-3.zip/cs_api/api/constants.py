GROUP_USER = "user"
GROUP_ADMIN = "admin"