GROUP_USER = "user"
GROUP_ADMIN = "admin"

HEADER_LAST = "last"
HEADER_FIRST = "first"
HEADER_NEXT = "next"
HEADER_PREV = "prev"